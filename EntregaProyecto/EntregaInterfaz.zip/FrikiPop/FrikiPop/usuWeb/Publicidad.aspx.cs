﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace usuWeb {
    public partial class Publicidad : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {

        }

        protected void GridView_SelectedIndexChanged(object sender, EventArgs e) {

        }

        protected void anyadir_Click(object sender, EventArgs e) {

        }

        protected void borrar_Click(object sender, EventArgs e) {

        }

        protected void Volver_Click(object sender, EventArgs e) {

        }

        protected void id_p_TextChanged(object sender, EventArgs e) {

        }

        protected void id_e_TextChanged(object sender, EventArgs e) {

        }

        protected void link_e_TextChanged(object sender, EventArgs e) {

        }

        protected void imagen_TextChanged(object sender, EventArgs e) {

        }
    }
}